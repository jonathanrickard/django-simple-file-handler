default_app_config = 'django_simple_file_handler.apps.Config'
