import setuptools


setuptools.setup()
